# In order to run, this program requires 
- numpy
- sounddevice
- pyqtgraph
- PyQt6
- scipy
The graph shows a histogram of the frequencies from A0 to A7
This program was run in the Anaconda environment to make it easier  
to set up your own env to run it.

